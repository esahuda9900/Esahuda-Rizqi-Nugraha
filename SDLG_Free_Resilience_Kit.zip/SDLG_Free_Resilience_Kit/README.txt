SDLG Warranty Claim — Free Resilience Kit

Includes:
- .github/workflows/sdlg-supabase-backup.yml
- SETUP.md
- RESTORE_CHECKLIST.md

Designed for zero paid spend.
